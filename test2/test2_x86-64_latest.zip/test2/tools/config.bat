set name=test2
set ctcmd_repo=git@github.com:xingguangcuican6666/ctcmd_repo_template.git
set ctcmd_upload="C:\Program Files\ctcmd\module\..\libctcmd\repo\ctcmd_upload.bat"
